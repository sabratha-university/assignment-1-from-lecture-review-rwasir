public interface Adjustable {
    void resize(double factor);
}
