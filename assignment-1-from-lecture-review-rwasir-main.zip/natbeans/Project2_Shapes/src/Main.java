public class Main {
    public static void main(String[] args) {
        Circle c = new Circle("Circle1", 5);
        c.draw();
        c.move();
        c.resize(1.5);
    }
}
