public interface Movable {
    void move();
}
